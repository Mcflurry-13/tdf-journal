#!/bin/zsh
cd -- "${0:A:h}"
python3 -u backend/server.py --mode display
