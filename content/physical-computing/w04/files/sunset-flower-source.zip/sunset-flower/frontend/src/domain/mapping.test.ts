import { describe, expect, it } from 'vitest';
import { lightLevel, lightOpening, peakFromQuality, smoothstep, tierFromQuality, visualOpen } from './mapping';

describe('quality → peak angle (flower.ino)', () => {
  it.each([
    [0, 5],
    [0.39, 109],
    [0.6, 165],
    [0.85, 165],
    [1, 165],
  ])('q=%s → %s°', (q, deg) => {
    expect(peakFromQuality(q)).toBeCloseTo(deg, 6);
  });

  it('draws 39 as 65% open, not fully open', () => {
    expect(visualOpen(peakFromQuality(0.39))).toBeCloseTo(0.65, 6);
    expect(visualOpen(peakFromQuality(0.6))).toBe(1);
  });
});

describe('light', () => {
  it('uses the firmware tier thresholds', () => {
    expect(tierFromQuality(0.32)).toBe('yellow');
    expect(tierFromQuality(0.33)).toBe('orange');
    expect(tierFromQuality(0.39)).toBe('orange');
    expect(tierFromQuality(0.669)).toBe('orange');
    expect(tierFromQuality(0.67)).toBe('red');
  });

  it('is brightest at this run’s peak and off when closed', () => {
    const peak = peakFromQuality(0.39);
    expect(lightOpening(peak, peak)).toBe(1);
    expect(lightOpening(5, peak)).toBe(0);
    expect(lightLevel(5, peak, 0.39)).toBe(0);
    // firmware total = round((16 + 35q) × opening²) of a 51 maximum
    expect(lightLevel(peak, peak, 0.39) * 51).toBeCloseTo(16 + 35 * 0.39, 6);
  });

  it('stays off for score 0 (zero span)', () => {
    expect(lightOpening(5, peakFromQuality(0))).toBe(0);
  });
});

describe('smoothstep', () => {
  it('is t²(3−2t)', () => {
    expect(smoothstep(0)).toBe(0);
    expect(smoothstep(0.5)).toBe(0.5);
    expect(smoothstep(1)).toBe(1);
    expect(smoothstep(0.25)).toBeCloseTo(0.15625, 9);
  });
});
