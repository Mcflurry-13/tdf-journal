import { describe, expect, it } from 'vitest';
import { sampleMotion, type MotionPlan } from './motion';
import { peakFromQuality, MOVE_MS, HOLD_MS } from './mapping';
const plan = (p: Partial<MotionPlan>): MotionPlan => ({ mode: 'breathe', fromDeg: 5, peakDeg: 150, startMs: 0, firmwareLeadIn:true, ...p });
describe('slower full-range breathe', () => {
  it('takes 3 seconds per movement and pauses 1.5 seconds', () => {
    expect(MOVE_MS).toBe(3000); expect(HOLD_MS).toBe(1500);
    expect(sampleMotion(plan({}), 3750).deg).toBe(5);
    expect(sampleMotion(plan({}), 6000)).toEqual({deg:77.5,phase:'opening'});
    expect(sampleMotion(plan({}), 8000)).toEqual({deg:150,phase:'holding'});
    expect(sampleMotion(plan({}), 10500)).toEqual({deg:77.5,phase:'closing'});
    expect(sampleMotion(plan({}), 12500).deg).toBe(5);
  });
  it('uses full range for every forecast score including zero', () => {
    for (const q of [0,.39,.6,1]) {
      const holdPeak=peakFromQuality(q);
      expect(sampleMotion(plan({peakDeg:150}),8000).deg).toBe(150);
      expect(sampleMotion(plan({mode:'display',peakDeg:holdPeak}),3000).deg).toBe(holdPeak);
    }
  });
});
describe('hold and stop', () => {
  it('holds today’s 39-point forecast at 109 degrees', () => {
    expect(sampleMotion(plan({mode:'display',peakDeg:109}),1500).deg).toBe(57);
    expect(sampleMotion(plan({mode:'display',peakDeg:109}),9000).deg).toBe(109);
  });
  it('stop freezes the current angle', () => {
    expect(sampleMotion(plan({mode:'off',fromDeg:80}),5000)).toEqual({deg:80,phase:'stopped'});
  });
});
