import { createHttpAdapter } from './httpAdapter';
export const selectAdapter = () => createHttpAdapter();
