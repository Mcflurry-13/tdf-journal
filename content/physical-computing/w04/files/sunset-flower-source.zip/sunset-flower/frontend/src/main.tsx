import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
// Fonts live in src/assets/fonts (no network needed in class); CSS stacks fall back to Georgia / system sans.
import './fonts.css';
import './styles.css';
import App from './App';




createRoot(document.getElementById('root')!).render(<StrictMode><App /></StrictMode>);
