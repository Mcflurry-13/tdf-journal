import type { FlowerAdapter } from './adapter';
import type { FlowerState } from '../domain/types';
export interface HttpAdapterOptions { baseUrl?: string }
export function createHttpAdapter({ baseUrl = '' }: HttpAdapterOptions = {}): FlowerAdapter {
  let last: FlowerState | null = null;
  let generation = 0;
  const listeners = new Set<(s: FlowerState) => void>();
  let timer: ReturnType<typeof setTimeout> | undefined;
  const publish = (s: FlowerState) => { last = s; listeners.forEach(fn => fn(s)); return s; };
  const request = async (path: string, body?: object): Promise<FlowerState> => {
    const seq = ++generation;
    const response = await fetch(baseUrl + path, {
      method: body ? 'POST' : 'GET', cache: 'no-store', signal: AbortSignal.timeout(5000),
      headers: body ? { 'Content-Type': 'application/json' } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || 'Local service unavailable');
    if (data.schemaVersion !== 1 || data.transport !== 'http' || !data.forecast || !data.mode || !data.motion) throw new Error('Invalid service state');
    if (seq === generation) return publish(data);
    return last ?? data;
  };
  const poll = async () => {
    try { await request('/api/state'); }
    catch (e) {
      if (last) publish({ ...last, device: { connected: false, status: 'disconnected' },
        mode: { ...last.mode, confirmed: null, pending: false, error: e instanceof Error ? e.message : 'Connection lost' } });
    }
    if (listeners.size) timer = setTimeout(poll, 500);
  };
  return { kind: 'http', getState: () => request('/api/state'),
    reconnect: () => request('/api/reconnect', {}),
    setMode: mode => request('/api/mode', { mode }), stop: () => request('/api/stop', {}),
    subscribe: fn => { listeners.add(fn); if (listeners.size === 1) timer = setTimeout(poll, 500);
      return () => { listeners.delete(fn); if (!listeners.size) clearTimeout(timer); }; },
  };
}
