SUNSET FLOWER

A physical flower displays Berkeley sunset quality through petal position and
light. A Mac retrieves real Sunsethue forecasts and sends them to an ESP32 over
USB. The webpage provides controls and an animated illustration.

MODES
Hold: stays at today's forecast angle. For quality q (0–1), the angle is
5 + min(q / 0.60, 1) × 160°. For example, 39/100 gives 109°.
Breathe: cycles between 5° and 150°, independently of the forecast score.
Each movement takes 3 seconds, followed by a 1.5-second pause.
Stop: stops servo control and turns off the LEDs; power remains connected.
Reconnect: reconnects USB, refreshes the forecast and restores the selected mode.
Light color follows forecast quality: yellow below 33, orange below 67, red at 67+.
Hold retains its original maximum of 165°; check linkage clearance at high scores.

FILES
firmware/flower/flower.ino   ESP32 firmware
backend/                    Python API and USB service
frontend/                   Web interface source and built files
models/housing/             Cylindrical housing, lid, ring and servo mount
models/petals/              Upper and lower petals
assets/                     Display image
docs/                       Wiring, API, model and asset notes
start.command               Start in Hold mode
README.zh.txt               Chinese version of this guide

SETUP
Use macOS with Python 3.9+, an Internet connection and USB.
Board: Adafruit Feather ESP32 V2. Verified Arduino dependencies:
esp32 core 4.0.0-alpha1; Adafruit NeoPixel 1.15.5.
Open firmware/flower/flower.ino in Arduino IDE and upload to the board.
Close other USB controllers and Serial Monitor first. Use 115200 upload speed.
Connect external 5V power for the servo and LEDs, with a common ground; see docs/wiring.txt.

START
Double-click start.command, or run from this folder:
  python3 -u backend/server.py --mode display
Open http://127.0.0.1:8765/ and keep the terminal open.
The program uses the saved macOS Keychain entry when available. Otherwise, enter
your own Sunsethue API key at the hidden terminal prompt. No key is included.
A fresh forecast is requested every five minutes. API failure stops the outputs;
no sample score is substituted. After restoring a USB connection, click Reconnect.
Closing the webpage does not stop the device. Press Ctrl+C in the terminal to exit.
