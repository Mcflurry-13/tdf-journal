"""One narrowly scoped macOS Keychain item; never invokes a shell with secrets."""
import ctypes as C
import json
import sys
import threading


class KeychainError(RuntimeError):
    pass


class ConnectionKeychain:
    def __init__(self, service="edu.berkeley.sunset-flower.connection",
                 account="ESP32-8C94DF2EE088"):
        self.service = service.encode("utf-8")
        self.account = account.encode("utf-8")
        self.lock = threading.Lock()
        self.security = None

    def _initialize(self):
        if self.security is not None:
            return
        if sys.platform != "darwin":
            raise KeychainError("Saved connections require macOS Keychain.")
        security = C.CDLL("/System/Library/Frameworks/Security.framework/Security")
        core = C.CDLL("/System/Library/Frameworks/CoreFoundation.framework/CoreFoundation")
        ptr, uint = C.c_void_p, C.c_uint32
        security.SecKeychainFindGenericPassword.argtypes = [
            ptr, uint, C.c_char_p, uint, C.c_char_p,
            C.POINTER(uint), C.POINTER(ptr), C.POINTER(ptr)]
        security.SecKeychainAddGenericPassword.argtypes = [
            ptr, uint, C.c_char_p, uint, C.c_char_p, uint, ptr, C.POINTER(ptr)]
        security.SecKeychainItemModifyAttributesAndData.argtypes = [ptr, ptr, uint, ptr]
        security.SecKeychainItemDelete.argtypes = [ptr]
        security.SecKeychainItemFreeContent.argtypes = [ptr, ptr]
        for name in ("SecKeychainFindGenericPassword", "SecKeychainAddGenericPassword",
                     "SecKeychainItemModifyAttributesAndData", "SecKeychainItemDelete",
                     "SecKeychainItemFreeContent"):
            getattr(security, name).restype = C.c_int32
        core.CFRelease.argtypes = [ptr]
        core.CFRelease.restype = None
        self.core, self.security = core, security

    def _find(self, length=None, data=None, item=None):
        self._initialize()
        return self.security.SecKeychainFindGenericPassword(
            None, len(self.service), self.service, len(self.account), self.account,
            length, data, item)

    @staticmethod
    def _check(status):
        if status:
            raise KeychainError(
                "macOS Keychain could not complete this action (code %d). "
                "Unlock your login keychain or allow the macOS prompt, then retry. "
                "You can also uncheck Remember to connect without saving." % status)

    def exists(self):
        # Query only this app's item, without retrieving the password data.
        with self.lock:
            status = self._find()
            if status == -25300:
                return False
            self._check(status)
            return True

    def load(self):
        with self.lock:
            size, data = C.c_uint32(), C.c_void_p()
            status = self._find(C.byref(size), C.byref(data))
            if status == -25300:
                raise KeychainError("No saved connection. Enter your details once below.")
            self._check(status)
            try:
                value = json.loads(C.string_at(data, size.value).decode("utf-8"))
                if not isinstance(value, dict):
                    raise ValueError()
                return value
            except (ValueError, UnicodeError):
                raise KeychainError("Saved connection could not be read. Please replace it.") from None
            finally:
                self.security.SecKeychainItemFreeContent(None, data)

    def save(self, value):
        payload = json.dumps({k: value[k] for k in ("ssid", "password", "key")},
                             ensure_ascii=True).encode("utf-8")
        with self.lock:
            item = C.c_void_p()
            status = self._find(item=C.byref(item))
            try:
                if status == -25300:
                    result = self.security.SecKeychainAddGenericPassword(
                        None, len(self.service), self.service, len(self.account),
                        self.account, len(payload), payload, None)
                else:
                    self._check(status)
                    result = self.security.SecKeychainItemModifyAttributesAndData(
                        item, None, len(payload), payload)
                self._check(result)
            finally:
                if item.value:
                    self.core.CFRelease(item)

    def forget(self):
        with self.lock:
            item = C.c_void_p()
            status = self._find(item=C.byref(item))
            if status == -25300:
                return
            self._check(status)
            try:
                self._check(self.security.SecKeychainItemDelete(item))
            finally:
                self.core.CFRelease(item)
