#!/usr/bin/env python3
"""macOS terminal-only Sunsethue -> ESP32. Standard library only; no web server."""
import argparse
import datetime as dt
import fcntl
import getpass
import glob
import json
import os
import secrets
import select
import sys
import termios
import time
import tty
from zoneinfo import ZoneInfo
from forecast import fetch_forecast, ForecastError
from keychain import ConnectionKeychain, KeychainError

READY = 'FLOWER_API_READY_V2'
TZ = ZoneInfo('America/Los_Angeles')

class Board:
    def __init__(self, port):
        self.fd = os.open(port, os.O_RDWR | os.O_NOCTTY | os.O_NONBLOCK)
        self.buffer = b''
        try:
            fcntl.flock(self.fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            if hasattr(termios, 'TIOCEXCL'):
                fcntl.ioctl(self.fd, termios.TIOCEXCL)
            tty.setraw(self.fd)
            attr = termios.tcgetattr(self.fd)
            attr[4] = attr[5] = termios.B115200
            attr[2] |= termios.CLOCAL | termios.CREAD
            attr[2] &= ~termios.HUPCL
            termios.tcsetattr(self.fd, termios.TCSANOW, attr)
        except BaseException:
            os.close(self.fd)
            raise
    def send(self, value):
        payload = ((json.dumps(value, separators=(',', ':')) if isinstance(value, dict) else value) + '\n').encode()
        deadline = time.monotonic() + 3
        while payload:
            if time.monotonic() >= deadline:
                raise TimeoutError('USB write timed out')
            if select.select([], [self.fd], [], .1)[1]:
                try:
                    sent = os.write(self.fd, payload)
                    payload = payload[sent:]
                except BlockingIOError:
                    pass
    def read_line(self, timeout):
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            if b'\n' in self.buffer:
                raw, self.buffer = self.buffer.split(b'\n', 1)
                return raw.decode('utf-8', errors='replace').strip()
            remaining = max(0, deadline-time.monotonic())
            if select.select([self.fd], [], [], remaining)[0]:
                try:
                    chunk = os.read(self.fd, 4096)
                except BlockingIOError:
                    continue
                if not chunk:
                    raise OSError('USB disconnected')
                self.buffer = (self.buffer + chunk)[-16384:]
        return None
    def wait_ready(self):
        deadline = time.monotonic() + 12
        while time.monotonic() < deadline:
            if self.read_line(.5) == READY:
                return
        raise TimeoutError('Firmware not recognized. Upload the current firmware and close other serial controllers.')
    def wait_json(self, predicate, timeout=6):
        deadline = time.monotonic()+timeout
        while time.monotonic()<deadline:
            line = self.read_line(.3)
            try:
                value = json.loads(line or '')
            except ValueError:
                continue
            if not isinstance(value, dict):
                continue
            if 'error' in value:
                raise RuntimeError('Device rejected command: ' + str(value['error']))
            if predicate(value):
                return value
        raise TimeoutError('Device acknowledgment timed out.')
    def stop(self):
        self.send('x')
        self.wait_json(lambda v: v.get('mode') == 'off')
    def close(self):
        if hasattr(termios, 'TIOCNXCL'):
            try:
                fcntl.ioctl(self.fd, termios.TIOCNXCL)
            except OSError:
                pass
        os.close(self.fd)

def choose_port(explicit):
    if explicit:
        return explicit
    ports = sorted(set(glob.glob('/dev/cu.usbserial*')+glob.glob('/dev/cu.usbmodem*')))
    if len(ports) != 1:
        raise RuntimeError('Connect one USB board. Detected ports: ' + ', '.join(ports))
    return ports[0]

def load_key(force_prompt):
    if not force_prompt:
        try:
            saved = ConnectionKeychain()
            if saved.exists():
                key = saved.load().get('key')
                if isinstance(key, str) and key.strip():
                    print('使用此 Mac 钥匙串中原夕阳项目的 API key；不会把 API key 或 Wi-Fi 配置发给主控板。')
                    return key.strip()
        except KeychainError:
            print('无法读取原钥匙串条目，改为临时输入 API key。')
    if not sys.stdin.isatty():
        raise RuntimeError('需要在终端交互输入 API key；不要把 key 写进代码或命令参数。')
    key = getpass.getpass('Sunsethue API key（输入不显示，仅保存在本次内存中）: ').strip()
    if not key:
        raise RuntimeError('API key 不能为空。')
    return key

def deliver(board, packet, mode):
    # Never start a motor before a matching acknowledgment for today's packet.
    packet = dict(packet, epoch=int(time.time()), forecast_id=secrets.randbelow(2147483646)+1)
    board.send(packet)
    ack = board.wait_json(lambda v: v.get('ack') == packet['forecast_id'] and v.get('date') == packet['date'])
    expected = 5 + min(packet['quality']/.6, 1)*160
    if abs(ack.get('score', -100)-packet['quality']*100)>.01 or abs(ack.get('peak', -100)-expected)>.01:
        raise RuntimeError('主控板报告的分数/角度与5–165映射不一致。')
    if mode != 'off':
        board.send('s' if mode == 'breathe' else 'h')
        board.wait_json(lambda v: v.get('mode') == mode)
    return ack

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--port')
    parser.add_argument('--mode', choices=['breathe','display','off'], default='breathe')
    parser.add_argument('--ask-key', action='store_true', help='忽略旧钥匙串，临时输入key')
    args = parser.parse_args()
    board = None
    identified = False
    try:
        port = choose_port(args.port)
        print('请关闭 Arduino 串口监视器和旧控制器。本脚本运行时占用 USB。')
        board = Board(port)
        board.wait_ready(); identified = True
        board.stop()
        key = load_key(args.ask_key)
        print('已识别固件。模式：%s；真实数据加载后%s。Ctrl+C 停止并灭灯。' %
              (args.mode, '自动启动' if args.mode != 'off' else '保持停止'))
        due = 0
        next_heartbeat = 0
        last_date = dt.datetime.now(TZ).date().isoformat()
        while True:
            if time.monotonic() >= next_heartbeat:
                board.send('?')
                next_heartbeat = time.monotonic()+5
            current_date = dt.datetime.now(TZ).date().isoformat()
            if current_date != last_date:
                board.stop(); due = 0; last_date = current_date
            if time.monotonic() >= due:
                # Each refresh stops first. API failure stays stopped and retries later.
                board.stop()
                try:
                    packet = fetch_forecast(key)
                except ForecastError as error:
                    print('获取失败：%s；已停止，60秒后重试。不会使用演示分数。' % error)
                    due = time.monotonic()+60
                else:
                    ack = deliver(board, packet, args.mode)
                    color = '黄色' if packet['quality']<.33 else ('橙色' if packet['quality']<.67 else '红色')
                    print('%s Berkeley 夕阳 %.2f分 | %s | 开合 5°–%.2f° | %s' %
                          (packet['date'], packet['quality']*100, color, ack['peak'], args.mode), flush=True)
                    due = time.monotonic()+300
            # Drain USB; a later successful refresh can resume the selected mode.
            raw = board.read_line(.25)
            try:
                status = json.loads(raw or '')
            except ValueError:
                continue
            if isinstance(status, dict) and 'error' in status:
                if status['error'] == 'forecast_expired':
                    due = 0
                else:
                    raise RuntimeError('主控板错误：'+str(status['error']))
    except KeyboardInterrupt:
        print('\n正在停止。')
    except (OSError, TimeoutError, RuntimeError) as error:
        print('错误：%s' % error, file=sys.stderr)
        return 1
    finally:
        if board is not None:
            if identified:
                try:
                    board.send('x')
                    board.wait_json(lambda v: v.get('mode') == 'off', timeout=2)
                    print('主控板已确认停止PWM并灭灯；舵机电源仍连接。')
                except (OSError, TimeoutError, RuntimeError):
                    print('未能确认停止，请断开充电宝。', file=sys.stderr)
            board.close()
    return 0

if __name__ == '__main__':
    sys.exit(main())
