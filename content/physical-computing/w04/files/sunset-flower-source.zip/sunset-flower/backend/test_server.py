import datetime as dt,json,os,pty,select,threading,time,unittest,urllib.request,urllib.error
from functools import partial
from server import Controller,Handler,ThreadingHTTPServer,Board,today,peak,angle,ForecastError

class SerialSimulator:
    def __init__(self):
        self.master,self.slave=pty.openpty();self.path=os.ttyname(self.slave);self.running=True;self.commands=[];self.reject=False
        self.thread=threading.Thread(target=self.run,daemon=True);self.thread.start()
    def run(self):
        buf=b'';last=0
        while self.running:
            if time.monotonic()-last>.1:
                os.write(self.master,b'FLOWER_API_READY_V2\n');last=time.monotonic()
            if not select.select([self.master],[],[],.02)[0]:continue
            buf+=os.read(self.master,4096)
            while b'\n' in buf:
                row,buf=buf.split(b'\n',1);row=row.decode().strip()
                if row.startswith('{'):
                    p=json.loads(row);answer={'ack':p['forecast_id'],'date':p['date'],'score':p['quality']*100,'peak':peak(p['quality'])}
                    if self.reject:answer['peak']=999
                elif row in ('s','h','x'):
                    self.commands.append(row);answer={'mode':{'s':'breathe','h':'display','x':'off'}[row]}
                else:continue
                os.write(self.master,(json.dumps(answer)+'\n').encode())
    def close(self):
        self.running=False;self.thread.join(1);os.close(self.master);os.close(self.slave)

def packet():
    return {'cmd':'forecast','quality':.39,'date':today(),'fetched_at':int(time.time()),'event_time':dt.datetime.now(dt.timezone.utc).isoformat(),'quality_text':'sample'}

class Tests(unittest.TestCase):
    def setUp(self):self.sim=SerialSimulator();self.c=Controller(lambda:Board(self.sim.path),packet);self.worker=None
    def tearDown(self):
        self.c.quit.set()
        if self.worker:self.worker.join(4)
        self.sim.close()
    def start(self):self.worker=threading.Thread(target=self.c.run);self.worker.start()
    def wait(self,predicate):
        deadline=time.monotonic()+4
        while time.monotonic()<deadline:
            if predicate():return
            time.sleep(.02)
        self.fail(str(self.c.snapshot()))
    def test_serial_modes(self):
        self.start();self.wait(lambda:self.c.snapshot()['mode']['confirmed']=='breathe')
        self.assertEqual(self.c.snapshot()['motion']['peakDeg'],109)
        self.assertEqual(self.c.snapshot()['motion']['timeline']['peakDeg'],150)
        self.c.request('display');self.wait(lambda:self.c.snapshot()['mode']['confirmed']=='display')
        self.c.request('off');self.wait(lambda:self.c.snapshot()['mode']['confirmed']=='off')
        self.assertEqual(self.sim.commands[-1],'x')
    def test_refresh_keeps_selected_mode(self):
        board=Board(self.sim.path)
        try:
            board.wait_ready();self.c.reconnect_event.clear();self.c.state['mode']['desired']='display'
            self.c.refresh(board);self.c.refresh(board)
            self.assertEqual(self.c.snapshot()['mode']['confirmed'],'display')
            self.assertNotIn('s',self.sim.commands)
        finally:board.stop();board.close()
    def test_reconnect_fetches_new_quality_and_preserves_hold(self):
        self.start();self.wait(lambda:self.c.snapshot()['mode']['confirmed']=='breathe')
        self.c.request('display');self.wait(lambda:self.c.snapshot()['mode']['confirmed']=='display')
        def fresh():
            p=packet();p['quality']=.6;return p
        self.c.fetch=fresh
        self.c.reconnect();self.c.reconnect()
        self.wait(lambda:self.c.snapshot()['motion']['peakDeg']==165 and not self.c.snapshot()['device']['reconnecting'])
        self.assertEqual(self.c.snapshot()['mode']['confirmed'],'display')
        self.assertTrue(self.c.snapshot()['device']['connected'])
    def test_reconnect_after_failed_open(self):
        original=self.c.factory
        self.c.factory=lambda: (_ for _ in ()).throw(OSError('USB unplugged'))
        self.start();self.wait(lambda:self.c.snapshot()['device']['status']=='error')
        self.c.factory=original;self.c.reconnect()
        self.wait(lambda:self.c.snapshot()['mode']['confirmed']=='breathe')
        self.assertTrue(self.c.snapshot()['device']['connected'])
    def test_invalid_ack_never_starts(self):
        self.sim.reject=True;self.start();self.wait(lambda:self.c.snapshot()['device']['status']=='error')
        self.assertNotIn('s',self.sim.commands);self.assertNotIn('h',self.sim.commands)
    def test_api_failure_stops(self):
        def fail():raise ForecastError('offline')
        self.c.fetch=fail;self.start();self.wait(lambda:self.c.snapshot()['forecast']['status']=='error')
        self.assertEqual(self.c.snapshot()['mode']['confirmed'],'off')
        self.assertNotIn('s',self.sim.commands)
    def test_http_origin_and_null_state(self):
        http=ThreadingHTTPServer(('127.0.0.1',0),partial(Handler,controller=self.c));t=threading.Thread(target=http.serve_forever);t.start()
        url='http://127.0.0.1:'+str(http.server_port)
        try:
            s=json.load(urllib.request.urlopen(url+'/api/state'));self.assertIsNone(s['forecast']['quality'])
            req=urllib.request.Request(url+'/api/mode',data=b'{"mode":"display"}',headers={'Content-Type':'application/json','Origin':'https://evil.example'})
            with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(req)
            self.assertEqual(e.exception.code,403)
        finally:http.shutdown();http.server_close();t.join()
    def test_timeline_and_zero(self):
        self.assertEqual(angle(('breathe',0,5,165),3.75),5)
        self.assertEqual(angle(('breathe',0,5,165),6),85)
        self.assertEqual(angle(('breathe',0,90,5),6),5)
        self.assertEqual(angle(('display',0,5,109),10),109)
        self.assertEqual(angle(('off',0,57,109),10),57)
if __name__=='__main__':unittest.main()
