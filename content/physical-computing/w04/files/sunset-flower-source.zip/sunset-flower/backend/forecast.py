"""Verified HTTPS retrieval of genuine Berkeley Sunsethue data. No secrets logged."""
import datetime as dt
import hashlib
import json
import math
import ssl
import time
import urllib.error
import urllib.request
from zoneinfo import ZoneInfo

BERKELEY = ZoneInfo('America/Los_Angeles')
CACHE = {}

class ForecastError(RuntimeError):
    pass

class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None

def validate(body, today, epoch):
    try:
        data = json.loads(body)['data']
        q = data['quality']
        if isinstance(q, bool) or not isinstance(q, (int, float)) or not math.isfinite(q) or not 0 <= q <= 1:
            raise ValueError()
        event = data['time']
        event_dt = dt.datetime.fromisoformat(event.replace('Z', '+00:00'))
        if data.get('model_data') is not True or data.get('type') != 'sunset' or event_dt.tzinfo is None:
            raise ValueError()
        if event_dt.astimezone(BERKELEY).date().isoformat() != today:
            raise ValueError()
        label = data.get('quality_text', '')
        if not isinstance(label, str):
            raise ValueError()
        return dict(cmd='forecast', quality=q, date=today, event_time=event,
                    quality_text=label[:80], epoch=epoch, fetched_at=epoch,
                    http_status=200, model_data=True, source='sunsethue_api')
    except (ValueError, TypeError, KeyError, AttributeError):
        raise ForecastError("API response did not contain a valid sunset forecast for today. No invented score was used.") from None

def fetch_forecast(key):
    epoch = int(time.time())
    today = dt.datetime.fromtimestamp(epoch, BERKELEY).date().isoformat()
    identity = hashlib.sha256(key.encode()).digest()
    if CACHE.get('date') == today and CACHE.get('key_id') == identity and time.monotonic() - CACHE.get('at', 0) < 300:
        return dict(CACHE['packet'], epoch=epoch)
    request = urllib.request.Request(
        'https://api.sunsethue.com/event?latitude=37.87&longitude=-122.27&date=' + today + '&type=sunset',
        headers={'x-api-key': key, 'User-Agent': 'SunsetFlowerClassProject/1.0 (educational display)'})
    opener = urllib.request.build_opener(NoRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))
    for attempt in range(2):
        try:
            with opener.open(request, timeout=15) as response:
                if response.status != 200:
                    raise ForecastError('API returned HTTP %d.' % response.status)
                body = response.read(65537)
                if len(body) > 65536:
                    raise ForecastError('API response was unexpectedly large.')
            packet = validate(body, today, int(time.time()))
            CACHE.update(date=today, key_id=identity, at=time.monotonic(), packet=dict(packet))
            return packet
        except urllib.error.HTTPError as error:
            raise ForecastError('API returned HTTP %d. Check the saved API key or request limit.' % error.code) from None
        except (urllib.error.URLError, TimeoutError, OSError):
            if attempt:
                raise ForecastError('Could not reach the API. Check the computer internet connection and retry.') from None
            time.sleep(0.5)
