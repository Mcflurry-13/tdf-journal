#!/usr/bin/env python3
"""Loopback HTTP + one serial owner. No keys or raw serial commands exposed."""
import argparse, copy, datetime as dt, json, math, queue, secrets, signal, threading, time
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlsplit
from serial_controller import Board, choose_port, load_key, TZ
from forecast import fetch_forecast, ForecastError, CACHE

ROOT = Path(__file__).resolve().parents[1]

def today(): return dt.datetime.now(TZ).date().isoformat()
def peak(q): return 5 + min(q/.6, 1)*160

def angle(plan, now):
    if plan is None: return 90.
    mode, start, origin, top = plan
    t=max(0,now-start)
    ease=lambda v: (lambda x: x*x*(3-2*x))(min(1,max(0,v)))
    if mode=='off': return origin
    if mode=='display': return origin+(top-origin)*ease(t/3)
    if t<3: return origin+(5-origin)*ease(t/3)
    if top<=5 or t<4.5: return 5.
    t=(t-4.5)%9
    if t<3: return 5+(top-5)*ease(t/3)
    if t<4.5: return top
    if t<7.5: return top+(5-top)*ease((t-4.5)/3)
    return 5.

class Controller:
    def __init__(self, board_factory, fetch, initial='breathe'):
        self.factory,self.fetch=board_factory,fetch
        self.lock=threading.RLock(); self.commands=queue.Queue(); self.quit=threading.Event()
        self.reconnect_event=threading.Event(); self.reconnect_event.set()
        self.plan=None; self.plan_id=0; self.packet=None
        self.state={'schemaVersion':1,'transport':'http','location':{'name':'Berkeley, California','timezone':'America/Los_Angeles'},
          'forecast':{'status':'loading','source':None,'date':None,'quality':None,'score':None,'qualityText':None,'fetchedAt':None,'eventTime':None},
          'device':{'connected':False,'status':'disconnected','reconnecting':True},
          'mode':{'desired':initial,'confirmed':None,'preview':None,'pending':False,'error':None},
          'motion':{'kind':'illustration','closedDeg':5,'limitDeg':165,'peakDeg':None,'angleMeasuredDeg':None,'moveMs':3000,'holdMs':1500},
          'image':{'src':'/media/sunset.png','kind':'ai_edited_illustration','caption':'AI-edited · Forecast-inspired illustration'}}
    def snapshot(self):
        with self.lock:
            s=copy.deepcopy(self.state)
            if self.plan:
                mode,start,origin,top=self.plan
                s['motion']['timeline']={'id':self.plan_id,'mode':mode,'fromDeg':origin,'peakDeg':top,'elapsedMs':max(0,(time.monotonic()-start)*1000)}
            return s
    def reconnect(self):
        with self.lock:
            if self.state['device'].get('reconnecting'): return self.snapshot()
            self.state['device'].update(reconnecting=True)
            self.state['mode'].update(pending=True,error=None)
            while not self.commands.empty():
                try:self.commands.get_nowait()
                except queue.Empty:break
            self.reconnect_event.set()
            return self.snapshot()
    def request(self, mode):
        with self.lock:
            if self.state['device'].get('reconnecting'): raise ValueError('Reconnecting USB')
            if not self.state['device']['connected']: raise ValueError('USB device not connected')
            if mode!='off' and (self.state['forecast']['status']!='current' or self.state['forecast']['date']!=today()): raise ValueError('No current forecast')
            if self.state['mode']['pending'] and mode!='off': raise ValueError('A command is pending')
            self.state['mode'].update(desired=mode,pending=True,error=None)
            self.commands.put(mode)
            return self.snapshot()
    def confirmed(self, mode, started):
        with self.lock:
            origin=angle(self.plan,started)
            top=150 if mode=='breathe' else (peak(self.packet['quality']) if self.packet else 5)
            self.plan=(mode,started,origin,top); self.plan_id+=1
            self.state['mode'].update(confirmed=mode,error=None)
    def command(self,board,mode):
        started=time.monotonic()
        board.send({'off':'x','display':'h','breathe':'s'}[mode])
        board.wait_json(lambda v:v.get('mode')==mode,timeout=3)
        self.confirmed(mode,started)
    def refresh(self,board):
        self.command(board,'off')
        with self.lock:
            self.state['forecast']['status']='loading'
        try: packet=self.fetch()
        except ForecastError as e:
            with self.lock:
                self.state['forecast'].update(status='error',quality=None,score=None)
                self.state['mode']['error']=str(e)
            return 60
        if packet['date']!=today(): raise RuntimeError('Forecast date mismatch')
        packet=dict(packet,epoch=int(time.time()),forecast_id=secrets.randbelow(2147483646)+1)
        board.send(packet)
        ack=board.wait_json(lambda v:v.get('ack')==packet['forecast_id'] and v.get('date')==packet['date'])
        for k,expected in [('score',packet['quality']*100),('peak',peak(packet['quality']))]:
            value=ack.get(k)
            if not isinstance(value,(int,float)) or not math.isfinite(value) or abs(value-expected)>.01: raise RuntimeError('Invalid forecast acknowledgment')
        with self.lock:
            self.packet=packet
            self.state['forecast'].update(status='current',source='sunsethue_api',date=packet['date'],quality=packet['quality'],score=packet['quality']*100,qualityText=packet.get('quality_text'),fetchedAt=packet['fetched_at'],eventTime=dt.datetime.fromisoformat(packet['event_time'].replace('Z','+00:00')).timestamp())
            self.state['motion']['peakDeg']=peak(packet['quality'])
            desired=self.state['mode']['desired']
        # Queued stop wins over resume. Queued requests are handled in the main loop.
        if not self.quit.is_set() and not self.reconnect_event.is_set() and self.commands.empty() and desired!='off': self.command(board,desired)
        print('Forecast %s: %.2f / 100, peak %.2f°'%(packet['date'],packet['quality']*100,peak(packet['quality'])),flush=True)
        return 300
    def run(self):
        while not self.quit.is_set():
            if not self.reconnect_event.wait(.1): continue
            self.reconnect_event.clear()
            with self.lock:
                self.state['device'].update(connected=False,status='disconnected',reconnecting=True)
                self.state['mode'].update(confirmed=None,pending=True,error=None)
                self.state['forecast'].update(status='loading',quality=None,score=None)
                self.packet=None; self.plan=None
            CACHE.clear()  # A user reconnect always fetches again, not the five-minute cache.
            self.run_connection()
    def run_connection(self):
        board=None
        try:
            board=self.factory();board.wait_ready();self.command(board,'off')
            with self.lock:self.state['device'].update(connected=True,status='connected')
            due=0; heartbeat=0
            while not self.quit.is_set() and not self.reconnect_event.is_set():
                if self.packet and self.packet['date']!=today():
                    self.command(board,'off'); self.packet=None; due=0
                    with self.lock:self.state['forecast'].update(status='stale',quality=None,score=None)
                try: mode=self.commands.get_nowait()
                except queue.Empty: mode=None
                if mode:
                    if mode!='off' and (not self.packet or self.packet['date']!=today()): raise RuntimeError('Forecast expired')
                    self.command(board,mode)
                    with self.lock:self.state['mode']['pending']=not self.commands.empty()
                if time.monotonic()>=due and self.commands.empty():
                    due=time.monotonic()+self.refresh(board)
                    with self.lock:
                        self.state['device']['reconnecting']=False
                        self.state['mode']['pending']=not self.commands.empty()
                if time.monotonic()>=heartbeat:
                    board.send('?');heartbeat=time.monotonic()+5
                raw=board.read_line(.1)
                try: status=json.loads(raw or '')
                except ValueError:continue
                if isinstance(status,dict) and 'error' in status: raise RuntimeError('Device: '+str(status['error']))
        except Exception as e:
            with self.lock:
                self.state['device'].update(connected=False,status='error',reconnecting=False)
                self.state['mode'].update(confirmed=None,pending=False,error=str(e))
            print('Controller error: '+str(e),flush=True)
        finally:
            if board:
                try:
                    self.command(board,'off');print('Device confirmed off.',flush=True)
                except Exception:
                    with self.lock:self.state['mode']['confirmed']=None
                board.close()
            with self.lock:
                self.state['device']['connected']=False
                if not self.reconnect_event.is_set(): self.state['device']['reconnecting']=False
                if self.state['device']['status']!='error':self.state['device']['status']='disconnected'
                self.state['mode']['pending']=False

class Handler(SimpleHTTPRequestHandler):
    def __init__(self,*a,controller,**kw): self.controller=controller;super().__init__(*a,directory=str(ROOT/'frontend/dist'),**kw)
    def log_message(self,*args):pass
    def allowed(self):
        expected='127.0.0.1:'+str(self.server.server_port)
        return self.headers.get('Host')==expected and self.headers.get('Origin', 'http://'+expected)=='http://'+expected
    def reply(self,status,data):
        payload=json.dumps(data).encode();self.send_response(status);self.send_header('Content-Type','application/json');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(payload)));self.end_headers();self.wfile.write(payload)
    def do_GET(self):
        if not self.allowed():return self.reply(403,{'error':'Local same-origin requests only'})
        path=urlsplit(self.path).path
        if path=='/api/state':return self.reply(200,self.controller.snapshot())
        if path.startswith('/api/'):return self.reply(404,{'error':'Not found'})
        if path=='/media/sunset.png':
            content=(ROOT/'assets/photos/sunset.png').read_bytes();self.send_response(200);self.send_header('Content-Type','image/png');self.send_header('Content-Length',str(len(content)));self.end_headers();self.wfile.write(content);return
        return super().do_GET()
    def do_POST(self):
        if not self.allowed():return self.reply(403,{'error':'Local same-origin requests only'})
        if self.headers.get('Content-Type')!='application/json':return self.reply(415,{'error':'JSON required'})
        try:
            length=int(self.headers.get('Content-Length','0'))
            if not 0<length<=512:raise ValueError('Invalid request size')
            data=json.loads(self.rfile.read(length));path=urlsplit(self.path).path
            if not isinstance(data,dict):raise ValueError('Object required')
            if path=='/api/reconnect':return self.reply(202,self.controller.reconnect())
            if path=='/api/stop':mode='off'
            elif path=='/api/mode' and data.get('mode') in ('display','breathe'):mode=data['mode']
            else:raise ValueError('Invalid command')
            self.reply(202,self.controller.request(mode))
        except (ValueError,TypeError) as e:self.reply(409,{'error':str(e)})

def main():
    p=argparse.ArgumentParser();p.add_argument('--port',type=int,default=8765);p.add_argument('--serial');p.add_argument('--mode',choices=['off','display','breathe'],default='breathe');args=p.parse_args()
    controller=Controller(lambda:Board(choose_port(args.serial)),lambda:fetch_forecast(key),args.mode)
    # Reserve HTTP port before touching hardware.
    server=ThreadingHTTPServer(('127.0.0.1',args.port),partial(Handler,controller=controller))
    key=load_key(False)
    worker=threading.Thread(target=controller.run);worker.start()
    signal.signal(signal.SIGTERM,lambda *_: (_ for _ in ()).throw(KeyboardInterrupt()))
    print('Open http://127.0.0.1:%d'%args.port,flush=True)
    try:server.serve_forever(poll_interval=.2)
    except KeyboardInterrupt:pass
    finally:
        controller.quit.set();server.server_close();worker.join(40)
if __name__=='__main__':main()
